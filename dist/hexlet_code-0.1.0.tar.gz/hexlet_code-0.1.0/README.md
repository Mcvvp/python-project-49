### Hexlet tests and linter status:
[![Actions Status](https://github.com/Mcvvp/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Mcvvp/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/057d5104969bab9d8b55/maintainability)](https://codeclimate.com/github/Mcvvp/python-project-49/maintainability)
